/*
 Navicat MySQL Data Transfer

 Source Server         : kk
 Source Server Type    : MySQL
 Source Server Version : 50717
 Source Host           : localhost:3306
 Source Schema         : kk

 Target Server Type    : MySQL
 Target Server Version : 50717
 File Encoding         : 65001

 Date: 27/04/2021 14:16:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course`  (
  `cno` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tID` char(9) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`cno`, `tID`) USING BTREE,
  INDEX `cno`(`cno`) USING BTREE,
  INDEX `5`(`tID`) USING BTREE,
  CONSTRAINT `5` FOREIGN KEY (`tID`) REFERENCES `teacher` (`tID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('201', 'aa', '101');
INSERT INTO `course` VALUES ('202', 'bb', '102');
INSERT INTO `course` VALUES ('203', 'cc', '103');

-- ----------------------------
-- Table structure for paper
-- ----------------------------
DROP TABLE IF EXISTS `paper`;
CREATE TABLE `paper`  (
  `cno` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sno` char(9) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `titleno` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sanswer` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `getscore` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`cno`, `sno`, `titleno`) USING BTREE,
  INDEX `2`(`sno`) USING BTREE,
  INDEX `3`(`titleno`) USING BTREE,
  CONSTRAINT `1` FOREIGN KEY (`cno`) REFERENCES `course` (`cno`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `2` FOREIGN KEY (`sno`) REFERENCES `student` (`sno`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `3` FOREIGN KEY (`titleno`) REFERENCES `title` (`titleno`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of paper
-- ----------------------------
INSERT INTO `paper` VALUES ('201', '001', '1', 'A', '10');
INSERT INTO `paper` VALUES ('201', '001', '2', 'B', '10');
INSERT INTO `paper` VALUES ('201', '001', '3', 'C', '10');
INSERT INTO `paper` VALUES ('201', '002', '1', 'B', '0');
INSERT INTO `paper` VALUES ('201', '002', '2', 'B', '10');
INSERT INTO `paper` VALUES ('201', '002', '3', 'C', '10');
INSERT INTO `paper` VALUES ('201', '003', '1', 'C', '0');
INSERT INTO `paper` VALUES ('201', '003', '2', 'B', '10');
INSERT INTO `paper` VALUES ('201', '003', '3', 'A', '10');
INSERT INTO `paper` VALUES ('202', '001', '1', 'B', '10');
INSERT INTO `paper` VALUES ('202', '001', '2', 'B', '0');
INSERT INTO `paper` VALUES ('202', '001', '3', 'B', '10');
INSERT INTO `paper` VALUES ('202', '002', '1', 'B', '10');
INSERT INTO `paper` VALUES ('202', '002', '2', 'A', '10');
INSERT INTO `paper` VALUES ('202', '002', '3', 'B', '10');
INSERT INTO `paper` VALUES ('202', '003', '1', 'C', '0');
INSERT INTO `paper` VALUES ('202', '003', '2', 'B', '0');
INSERT INTO `paper` VALUES ('202', '003', '3', 'A', '0');
INSERT INTO `paper` VALUES ('203', '001', '1', 'C', '10');
INSERT INTO `paper` VALUES ('203', '001', '2', 'A', '10');
INSERT INTO `paper` VALUES ('203', '001', '3', 'B', '10');
INSERT INTO `paper` VALUES ('203', '002', '1', 'C', '10');
INSERT INTO `paper` VALUES ('203', '002', '2', 'B', '0');
INSERT INTO `paper` VALUES ('203', '002', '3', 'A', '0');
INSERT INTO `paper` VALUES ('203', '003', '1', 'B', '0');
INSERT INTO `paper` VALUES ('203', '003', '2', 'A', '10');
INSERT INTO `paper` VALUES ('203', '003', '3', 'B', '10');

-- ----------------------------
-- Table structure for sc
-- ----------------------------
DROP TABLE IF EXISTS `sc`;
CREATE TABLE `sc`  (
  `cno` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sno` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `grade` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`cno`, `sno`) USING BTREE,
  INDEX `7`(`sno`) USING BTREE,
  CONSTRAINT `6` FOREIGN KEY (`cno`) REFERENCES `course` (`cno`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `7` FOREIGN KEY (`sno`) REFERENCES `student` (`sno`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sc
-- ----------------------------
INSERT INTO `sc` VALUES ('201', '001', '30');
INSERT INTO `sc` VALUES ('201', '002', '20');
INSERT INTO `sc` VALUES ('201', '003', '20');
INSERT INTO `sc` VALUES ('202', '001', '20');
INSERT INTO `sc` VALUES ('202', '002', '30');
INSERT INTO `sc` VALUES ('202', '003', '0');
INSERT INTO `sc` VALUES ('203', '001', '30');
INSERT INTO `sc` VALUES ('203', '002', '10');
INSERT INTO `sc` VALUES ('203', '003', '20');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `sno` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`sno`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('001', 'a', '000');
INSERT INTO `student` VALUES ('002', 'b', '111');
INSERT INTO `student` VALUES ('003', 'c', '222');

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher`  (
  `tID` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`tID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('101', '00');
INSERT INTO `teacher` VALUES ('102', '11');
INSERT INTO `teacher` VALUES ('103', '22');

-- ----------------------------
-- Table structure for title
-- ----------------------------
DROP TABLE IF EXISTS `title`;
CREATE TABLE `title`  (
  `cno` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `titleno` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `titlecontent` varchar(4) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `answer` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `score` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`cno`, `titleno`) USING BTREE,
  INDEX `titleno`(`titleno`) USING BTREE,
  CONSTRAINT `4` FOREIGN KEY (`cno`) REFERENCES `course` (`cno`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of title
-- ----------------------------
INSERT INTO `title` VALUES ('201', '1', 'AAAA', 'A', '10');
INSERT INTO `title` VALUES ('201', '2', 'BBBB', 'B', '10');
INSERT INTO `title` VALUES ('201', '3', 'CCCC', 'C', '10');
INSERT INTO `title` VALUES ('202', '1', 'DDDD', 'B', '10');
INSERT INTO `title` VALUES ('202', '2', 'EEEE', 'A', '10');
INSERT INTO `title` VALUES ('202', '3', 'FFFF', 'B', '10');
INSERT INTO `title` VALUES ('203', '1', 'HHHH', 'C', '10');
INSERT INTO `title` VALUES ('203', '2', 'IIII', 'A', '10');
INSERT INTO `title` VALUES ('203', '3', 'KKKK', 'B', '10');

-- ----------------------------
-- View structure for daan1
-- ----------------------------
DROP VIEW IF EXISTS `daan1`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `daan1` AS select `title`.`titleno` AS `titleno`,`title`.`titlecontent` AS `titlecontent`,`title`.`answer` AS `answer`,`title`.`score` AS `score` from `title` where (`title`.`cno` = 201);

-- ----------------------------
-- View structure for daan2
-- ----------------------------
DROP VIEW IF EXISTS `daan2`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `daan2` AS select `title`.`titleno` AS `titleno`,`title`.`titlecontent` AS `titlecontent`,`title`.`answer` AS `answer`,`title`.`score` AS `score` from `title` where (`title`.`cno` = 202);

-- ----------------------------
-- View structure for daan3
-- ----------------------------
DROP VIEW IF EXISTS `daan3`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `daan3` AS select `title`.`titleno` AS `titleno`,`title`.`titlecontent` AS `titlecontent`,`title`.`answer` AS `answer`,`title`.`score` AS `score` from `title` where (`title`.`cno` = 203);

-- ----------------------------
-- View structure for shijuan
-- ----------------------------
DROP VIEW IF EXISTS `shijuan`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `shijuan` AS select `paper`.`sno` AS `sno`,`paper`.`titleno` AS `titleno`,`paper`.`sanswer` AS `sanswer`,`paper`.`getscore` AS `getscore` from `paper` where (`paper`.`cno` = 201);

-- ----------------------------
-- Procedure structure for 修改
-- ----------------------------
DROP PROCEDURE IF EXISTS `修改`;
delimiter ;;
CREATE PROCEDURE `修改`()
BEGIN
	#Routine body goes here...
UPDATE student SET password=666 where sno=004;

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for 删除
-- ----------------------------
DROP PROCEDURE IF EXISTS `删除`;
delimiter ;;
CREATE PROCEDURE `删除`()
BEGIN
	#Routine body goes here...
DELETE from student where sno=005;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for 增加
-- ----------------------------
DROP PROCEDURE IF EXISTS `增加`;
delimiter ;;
CREATE PROCEDURE `增加`()
BEGIN
	#Routine body goes here...
insert into student VALUES("004","d",333),("005","e",444);

END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for 查询
-- ----------------------------
DROP PROCEDURE IF EXISTS `查询`;
delimiter ;;
CREATE PROCEDURE `查询`()
BEGIN
	#Routine body goes here...
select * from sc where sno=002;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
